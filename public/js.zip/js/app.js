// Dark/Light Mode
function toggleMode() {
    document.body.classList.toggle("dark");
    const btn = document.querySelector(".toggle-btn");
    if(document.body.classList.contains("dark")) {
        btn.textContent = "☀️ Light Mode";
        localStorage.setItem("theme", "dark");
    } else {
        btn.textContent = "🌙 Dark Mode";
        localStorage.setItem("theme", "light");
    }
}

// Load theme
window.onload = () => {
    const theme = localStorage.getItem("theme");
    if(theme === "dark") {
        document.body.classList.add("dark");
        document.querySelector(".toggle-btn").textContent = "☀️ Light Mode";
    }
    loadData();
}

// Fetch and display user data
async function loadData() {
    try {
        const res = await fetch('/api/data'); // Ensure backend serves room-specific data
        const data = await res.json();

        displayCards(data);
        renderCharts(data);

    } catch (err) {
        document.getElementById("usageCards").innerHTML = "<p>Error loading data...</p>";
        console.error(err);
    }
}

// Cards
function displayCards(data) {
    const container = document.getElementById("usageCards");
    container.innerHTML = "";

    const info = [
        {title: "Room", value: data.room || "N/A"},
        {title: "Current Usage (L)", value: data.currentUsage || 0},
        {title: "Total Usage (L)", value: data.totalUsage || 0},
        {title: "Amount Due (Tsh)", value: data.amountDue || 0},
        {title: "Last Reading", value: data.lastReading || "-"}
    ];

    info.forEach(item => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `<h3>${item.title}</h3><p>${item.value}</p>`;
        container.appendChild(card);
    });
}

// Charts
function renderCharts(data) {
    if(data.dailyUsage) {
        const ctx = document.getElementById("dailyChart").getContext("2d");
        new Chart(ctx, {
            type: "line",
            data: {
                labels: Object.keys(data.dailyUsage),
                datasets: [{
                    label: "Daily Usage (Liters)",
                    data: Object.values(data.dailyUsage),
                    borderColor: "#0077b6",
                    backgroundColor: "rgba(0,119,182,0.1)",
                    fill: true,
                    tension: 0.3
                }]
            },
            options: { responsive: true }
        });
    }

    if(data.monthlyUsage) {
        const ctx2 = document.getElementById("monthlyChart").getContext("2d");
        new Chart(ctx2, {
            type: "bar",
            data: {
                labels: Object.keys(data.monthlyUsage),
                datasets: [{
                    label: "Monthly Usage (Liters)",
                    data: Object.values(data.monthlyUsage),
                    backgroundColor: "#0077b6"
                }]
            },
            options: { responsive: true }
        });
    }
}

// PWA: Service Worker
if('serviceWorker' in navigator){
    navigator.serviceWorker.register('service-worker.js')
    .then(() => console.log("Service Worker Registered"));
}
