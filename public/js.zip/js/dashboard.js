async function fetchData() {
    try {
        const res = await fetch('/api/data');
        if(res.status === 401){ window.location.href='/login.html'; return; }
        const data = await res.json();

        // Cards
        const container = document.getElementById('dataContainer');
        container.innerHTML = "";
        const keys = ['room','currentUsage','totalUsage','amountDue','lastReading'];
        keys.forEach(k=>{
            const card = document.createElement('div');
            card.className = 'card';
            card.innerHTML = `<h3>${k}</h3><p>${data[k]}</p>`;
            container.appendChild(card);
        });

        // Daily chart
        const ctxD = document.getElementById('dailyChart').getContext('2d');
        new Chart(ctxD, {
            type:'line',
            data:{
                labels:Object.keys(data.dailyUsage),
                datasets:[{label:'Liters',data:Object.values(data.dailyUsage),borderColor:'#0077b6',fill:false,tension:0.3}]
            },
            options:{responsive:true}
        });

        // Monthly chart
        const ctxM = document.getElementById('monthlyChart').getContext('2d');
        new Chart(ctxM, {
            type:'bar',
            data:{
                labels:Object.keys(data.monthlyUsage),
                datasets:[{label:'Liters',data:Object.values(data.monthlyUsage),backgroundColor:'#00b4d8'}]
            },
            options:{responsive:true}
        });

    } catch(err){
        console.log(err);
    }
}
fetchData();

// Dark mode toggle
function toggleMode(){
    document.body.classList.toggle('dark');
    const btn = document.querySelector('.toggle-btn');
    if(document.body.classList.contains('dark')) btn.textContent="☀️ Light Mode";
    else btn.textContent="🌙 Dark Mode";
}

// Logout
async function logout(){
    await fetch('/api/logout');
    window.location.href='/login.html';
}

// Load theme
window.onload = ()=>{
    const theme = localStorage.getItem('theme');
    if(theme==='dark'){ document.body.classList.add('dark'); document.querySelector('.toggle-btn').textContent="☀️ Light Mode"; }
};
